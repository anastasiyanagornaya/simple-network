const setLoggedOut = userObj => ({
    type: 'SET_OUT',
    payload: userObj
})